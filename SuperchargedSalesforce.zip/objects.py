import os
import xml.etree.ElementTree as ET

def create_object_summary(documentation_directory):
    objects_directory = os.path.join(documentation_directory, '..', 'force-app', 'main', 'default', 'objects')
    object_summaries = []

    if os.path.exists(objects_directory) and os.path.isdir(objects_directory):
        for objectname in os.listdir(objects_directory):
            object_path = os.path.join(objects_directory, objectname, 'fields')
            if os.path.exists(object_path) and os.path.isdir(object_path):
                summary = f"Object: {objectname}\nFields:\n"
                
                for field_file in os.listdir(object_path):
                    if field_file.endswith('.field-meta.xml'):
                        field_path = os.path.join(object_path, field_file)
                        tree = ET.parse(field_path)
                        root = tree.getroot()
                        
                        field_name = field_file.replace('.field-meta.xml', '')
                        field_type = root.find('.//{*}type')
                        field_type_value = field_type.text if field_type is not None else "Unknown"
                        
                        required = root.find('.//{*}required')
                        is_required = " (Required)" if required is not None and required.text.lower() == 'true' else ""
                        
                        additional_info = ""
                        
                        if field_type_value == 'Picklist':
                            value_set = root.find('.//{*}valueSet')
                            if value_set is not None:
                                value_set_name = value_set.find('.//{*}valueSetName')
                                if value_set_name is not None:
                                    additional_info = f" (Global Valueset: {value_set_name.text})"
                                else:
                                    picklist_values = value_set.findall('.//{*}valueSetDefinition/{*}value/{*}fullName')
                                    if picklist_values:
                                        values = ', '.join([value.text for value in picklist_values])
                                        additional_info = f" (Values: {values})"
                        
                        elif field_type_value in ['Lookup', 'MasterDetail']:
                            referenced_object = root.find('.//{*}referenceTo')
                            if referenced_object is not None:
                                additional_info = f" (References: {referenced_object.text})"
                        
                        summary += f"{field_name} [{field_type_value}]{is_required}{additional_info}\n"
                
                summary_filename = os.path.join(documentation_directory, f"{objectname}_summary.txt")
                with open(summary_filename, 'w') as summary_file:
                    summary_file.write(summary)
                object_summaries.append(summary_filename)

    return object_summaries

def create_consolidated_summary(documentation_directory, object_summaries):
    consolidated_summary = "Data Model Summary\n\n"
    for summary_file in object_summaries:
        with open(summary_file, 'r') as file:
            consolidated_summary += file.read() + "\n\n"
    
    consolidated_summary_filename = os.path.join(documentation_directory, "Data Model Summary.txt")
    with open(consolidated_summary_filename, 'w') as file:
        file.write(consolidated_summary)

# Specify the path to the 'documentation' directory where the script will be run
documentation_directory = os.getcwd()

# Call the function and create summaries
summaries = create_object_summary(documentation_directory)

# Create consolidated summary
create_consolidated_summary(documentation_directory, summaries)