# create_field_files.py
import os
import sys

def generate_field_files(object_name):
    input_file = f"{object_name}.xml"
    output_dir = f"../../../force-app/main/default/objects/{object_name}/fields"

    # Read the XML content from the file
    with open(input_file, 'r') as file:
        xml_content = file.read()

    # Split the XML content into individual field metadata
    field_metadata_list = xml_content.split('<!-- ')[1:]

    # Create the output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)

    # Create individual files for each field
    for field_metadata in field_metadata_list:
        field_name, metadata = field_metadata.split(' -->\n', 1)
        field_filename = field_name.strip()

        with open(os.path.join(output_dir, field_filename), 'w') as file:
            file.write(metadata)

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Usage: python create_field_files.py <object_name>")
        sys.exit(1)

    object_name = sys.argv[1]
    generate_field_files(object_name)